int n;

void foo(){
	int n;
	n=1;
}

void main(){
	n=0;
	foo();
}
