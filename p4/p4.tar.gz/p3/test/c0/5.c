/*支持8进制，16进制数*/
int dec=16;
int hex=0x10;
int oct=020;

void main(){}
